-= DiffGen2 =-
Based on the work of Fabio's Diffgen, and the many hours DiffTeam have put into it
DiffGen2 modifys alot of DiffGen structure, and rewrote all Patch files to work with
VC9 compiled RagexeRE clients.
Patch files now use seperate files for each patch, with the patch function using the same
name as the patch filename.
all backwards compatability has been removed.

To run DiffGen2, PHP needs to be installed, then simply start the bat script.

Yommy 2010