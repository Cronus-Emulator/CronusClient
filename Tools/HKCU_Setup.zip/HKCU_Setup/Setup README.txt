Setup_HKLM_to_HKCU.diff :
This diff is for Setup.exe when you have patched you Ragnarok Executable with [Fix]_HKLM_to_HKCU diff.
You can use it with k3dt's patcher.

Setup.Exe :
Original Setup.exe file.

Setup_patched.exe :
Setup.Exe patched with HKLM_to_HKCU diff.